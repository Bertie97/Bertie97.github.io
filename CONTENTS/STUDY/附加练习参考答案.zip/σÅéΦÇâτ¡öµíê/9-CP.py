from math import factorial

def C_(n, k):
    n = int(n); k = int(k)
    if n <= 0 or not(0 <= k <= n): raise ValueError("n <= 0 or k is not in [0, n]")
    return factorial(n) // factorial(n-k) // factorial(k)

def P_(n, k):
    n = int(n); k = int(k)
    if n <= 0 or not(0 <= k <= n): raise ValueError("n <= 0 or k is not in [0, n]")
    return factorial(n) // factorial(n-k)

def _C(n, k):
    n = int(n); k = int(k)
    if k == -1 or k == n+1: return 0
    if n <= 0 or not(0 <= k <= n): raise ValueError("n <= 0 or k is not in [0, n]")
    if n == 1: return 1
    return _C(n-1, k) + _C(n-1, k-1)

def _P(n, k): return _C(n, k) * factorial(k)

def C(n, k):
    global Ctable
    n = int(n); k = int(k)
    if n <= 0 or not(0 <= k <= n): raise ValueError("n <= 0 or k is not in [0, n]")
    return Ctable[n][k]

def P(n, k): return C(n, k) * factorial(k)

Ctable = []
for n in range(101):
    Ctable.append([((Ctable[n-1][k] if k < n else 0) +
                    (Ctable[n-1][k-1] if k > 0 else 0)) if n > 1 else 1
                   for k in range(n+1)])

if __name__ == "__main__":
    # print(C(5, 2), P(5, 2))
    N = 10
    for n in range(N):
        print(' ' * (3*(N-n-1)) + ' '.join(['{:^5d}'.format(x) for x in Ctable[n]]))
