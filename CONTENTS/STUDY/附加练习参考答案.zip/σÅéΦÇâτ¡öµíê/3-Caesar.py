from string import ascii_lowercase as lc, ascii_uppercase as uc

def caesar(str_, k=3):
    shift = dict(list(zip(lc, lc[k:] + lc[:k])) + list(zip(uc, uc[k:] + uc[:k])))
    return ''.join([shift.get(c, c) for c in str_])

if __name__ == "__main__":
    string = input("Input string: ")
    print(' '*len("Input string: ") + caesar(string))
