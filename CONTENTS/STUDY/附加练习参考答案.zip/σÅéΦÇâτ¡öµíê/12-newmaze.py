
def newmaze():
    from random import randint, shuffle
    height, width = randint(8, 20), randint(8, 20)
    map = [[1 for _ in range(width)] for _ in range(height)]
    start = randint(0, height - 1), randint(0, width - 1)
    directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]

    stack = [start]
    visited = set()
    while len(stack) > 0:
        pos = stack.pop()
        visited.add(pos)
        count = 0
        for direction in directions:
            x, y = pos[0] + direction[0], pos[1] + direction[1]
            if not 0<=x<height or not 0<=y<width: continue
            if map[x][y] == 0: count += 1
        if count >= 2: continue
        map[pos[0]][pos[1]] = 0

        shuffle(directions)
        for direction in directions:
            x, y = pos[0] + direction[0], pos[1] + direction[1]
            if not 0<=x<height or not 0<=y<width: continue
            if (x, y) not in visited and randint(0, 4) > 0: stack.append((x, y))

    queue = [start]
    visited = set()
    pos = 0
    while len(queue) > 0:
        pos = queue.pop(0)
        visited.add(pos)
        for direction in directions:
            x, y = pos[0] + direction[0], pos[1] + direction[1]
            if not 0<=x<height or not 0<=y<width: continue
            if map[x][y] == 1: continue
            if (x, y) not in visited: queue.append((x, y))
    map[start[0]][start[1]] = -1
    map[pos[0]][pos[1]] = -2

    return map

def findpath(map):
    height = len(map); width = len(map[0])
    from flatlist import flatlist
    start = tuple(flatlist([[(i, j) for j in range(width) if map[i][j] == -1]
                                    for i in range(height)]))
    end   = tuple(flatlist([[(i, j) for j in range(width) if map[i][j] == -2]
                                    for i in range(height)]))

    queue = [(start, [start])]
    visited = set()
    while len(queue) > 0:
        pos, path = queue.pop(0)
        visited.add(pos)
        if pos == end:
            return path
        for direction in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            x, y = pos[0] + direction[0], pos[1] + direction[1]
            if not 0<=x<height or not 0<=y<width: continue
            if map[x][y] == 1: continue
            if (x, y) not in visited:
                visited.add((x, y))
                queue.append(((x, y), path + [(x, y)]))

def printpathonmap(path, map, symbol_start='@', symbol_end='#',
                              symbol_path='⋅', symbol_wall='▒'):
    for p in path:
        if map[p[0]][p[1]] == 0: map[p[0]][p[1]] = 2
    symbol = {-1: symbol_start, -2: symbol_end, 0: ' ', 1: symbol_wall, 2:symbol_path}
    print(' '.join([symbol_wall] * (len(map[0]) + 2)))
    print('\n'.join([' '.join([symbol_wall] + [symbol[x] for x in row] +
                              [symbol_wall]) for row in map]))
    print(' '.join([symbol_wall] * (len(map[0]) + 2)))

if __name__ == "__main__":
    m = newmaze()
    printpathonmap([], m); print()
    printpathonmap(findpath(m), m)
