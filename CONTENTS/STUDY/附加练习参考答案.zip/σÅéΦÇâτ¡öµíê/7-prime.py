from math import sqrt

def prime(N):
    N = int(N)
    primes = []
    for i in range(2, N):
        isprime = True
        for p in primes:
            if p > int(sqrt(i)): break
            if i % p == 0: isprime = False; break
        if isprime: primes.append(i)
    return primes

prime1e5 = prime(1e5)

if __name__ == "__main__":
    print(prime(100))
