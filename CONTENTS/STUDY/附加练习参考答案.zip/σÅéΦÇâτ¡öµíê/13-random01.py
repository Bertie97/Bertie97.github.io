
from random import randint
import os
import threading

width = 100; height = 40
dots = []; M = 10
prevInit = lambda : ([randint(0, width-1) for _ in range(M)],
                     [randint(50, 99) / 60 for _ in range(M)])
prevCols, prevVols = prevInit()
def ontimer():
    global dots, prevCols, prevVols
    os.system('clear')
    dots = [(d[0], d[1], d[2]+d[3], d[3]) for d in dots if d[2]+d[3] < height]
    for i in range(10):
        if randint(0, 99) < 40:
            prevCols[randint(0, M-1)] = randint(0, width-1)
            prevVols[randint(0, M-1)] = randint(50, 99) / 60
        dots.append((randint(0, 1), prevCols[i], 0, prevVols[i]))
    dots.sort(key=lambda d: d[2])
    row = [" " for _ in range(width)]
    rownum = 0
    for d in dots:
        if int(d[2]) > rownum:
            print(''.join(row))
            row = [" " for _ in range(width)]
            print('\n' * (int(d[2]) - rownum - 1), end='')
            rownum = int(d[2])
        if int(d[2]) == rownum:
            row[d[1]] = str(d[0])
    print(''.join(row))

    global timer
    timer = threading.Timer(0.1, ontimer) # 每0.1s执行一次ontimer
    timer.start()

ontimer()
