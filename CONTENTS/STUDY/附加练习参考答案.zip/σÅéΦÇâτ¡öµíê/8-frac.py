from prime import prime1e5

def frac(x):
    x = int(x)
    if x == 0: return [(0, 1)]
    factors = []
    for p in prime1e5:
        count = 0
        while x % p == 0: x //= p; count += 1
        if count > 0: factors.append((p, count))
    if x > 1: factors.append((x, 1))
    if x == 1 and len(factors) == 0: return [(1, 1)]
    if x == -1: factors.insert(0, (-1, 1))
    return factors

def symbolize(num, symbols):
    return ''.join([symbols[int(c)] for c in str(num)])

def printresult(x):
    factors = frac(x)
    sup = lambda x: symbolize(x, "⁰¹²³⁴⁵⁶⁷⁸⁹")
    print(x, '=', '×'.join([str(p[0]) + (sup(p[1]) if p[1] > 1 else '') for p in factors]))

if __name__ == "__main__":
    printresult(169400)
    printresult(2048)
    printresult(365)
    printresult(1)
    printresult(0)
    printresult(-10)
