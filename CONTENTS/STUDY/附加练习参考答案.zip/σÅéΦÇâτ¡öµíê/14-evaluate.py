
from math import e, pi
from tools import params, findall

def str2num(expr):
    try: return int(expr)
    except ValueError: pass
    try: return float(expr)
    except ValueError: raise ValueError("Wrong expression!!")

def calculate(expr, depth):
    global digits, operators
    for opr, dir, func in operators:
        if opr == '.':
            if func(expr) is not None: return func(expr)
            return str2num(expr)
        if opr.count('.') == 1:
            left, right = opr.split('.')
            ileft, iright = len(left), len(expr) - len(right)
            if expr[:ileft] != left or expr[iright:] != right: continue
            if '(' in opr: depth = [x-1 for x in depth]
            try:
                val_ = calculate(expr[ileft: iright], depth[ileft: iright])
            except ValueError: continue
            if val_ == None: raise ValueError("Wrong expression!")
            val_ = func(val_)
            return val_
        if opr.count('.') == 2:
            left, operator, right = opr.split('.')
            ileft, iright = len(left), len(expr)-len(right)
            if expr[:ileft] != left or expr[iright:] != right: continue
            p = 1; Texpr, Tdepth = expr[::dir], depth[::dir]
            try:
                while True:
                    p = Texpr.find(operator, p)
                    if p < 0: break
                    if Tdepth[p] > 0: p += 1; continue
                    if dir == -1: p = len(expr) - p - 1
                    ileft, iright = p, p + len(operator)
                    if ileft <= 0: break
                    return func(calculate(expr[:ileft], depth[:ileft]),
                                calculate(expr[iright:], depth[iright:]))
            except ValueError: continue
        if opr.count('.') >= 3: raise SyntaxError("Wrong operator - " + opr)


def evaluate(expr, **variables):
    global vars
    vars = variables
    vars.update({'pi': pi, 'e': e})

    expr = expr.split()
    ireplace = []
    for i in range(len(expr) - 1):
        if expr[i][-1] not in opchars and expr[i+1][0] not in opchars:
            ireplace.append(i+1)
    for i in ireplace[::-1]: expr.insert(i, '*')

    iinsert = []
    for i in range(len(expr) - 1):
        if expr[i] in digits and expr[i+1] not in digits and expr[i+1] not in opchars:
            iinsert.append(i+1)
    expr = list(expr)
    for i in iinsert[::-1]: expr.insert(i, '*')
    expr = ''.join(expr)

    depth, count = [], 0
    for c in expr:
        if c == '(': count += 1
        if c == ')': count -= 1
        depth.append(count)

    return calculate(expr, depth)


operators = [('.+.', -1, lambda x, y: x + y),
             ('.-.', -1, lambda x, y: x - y),
             ('.*.', -1, lambda x, y: x * y),
             ('./.', -1, lambda x, y: x / y),
             ('.^.', +1, lambda x, y: x ** y),
             ('.**.',+1, lambda x, y: x ** y),
             ('+.' ,  0, lambda x: x),
             ('-.' ,  0, lambda x: -x),
             ('(.)',  0, lambda x: x),
             ('.'  ,  0, lambda ex: vars.get(ex, None))]

digits = ".01223456789"
opchars = ''.join([x[0] for x in operators])

def moveCursorUp(): sys.stdout.write(chr(27)+chr(91)+chr(65))
def moveCursorDown(): sys.stdout.write(chr(27)+chr(91)+chr(66))
def moveCursorRight(): sys.stdout.write(chr(27)+chr(91)+chr(67))
def moveCursorLeft(): sys.stdout.write(chr(27)+chr(91)+chr(68))
@params
def rightShiftCursor(offset:int):
    if offset > 0:
        for i in range(offset): moveCursorRight()
    else:
        for i in range(-offset): moveCursorLeft()
    sys.stdout.flush()

import sys, tty, termios
def RealTimeInput(string):
    global preinputs
    sys.stdout.write(string)
    sys.stdout.flush()
    try: preinputs
    except NameError: preinputs = []
    curinput, cursor, nextinputs = '', 0, []
    while True:
        fd=sys.stdin.fileno()
        old_settings=termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
        except: pass
        finally: termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        if ord(ch) == 27:
            ch = sys.stdin.read(1)
            if ord(ch) == 91:
                ch = sys.stdin.read(1)
                dir = ord(ch) - 65
                if dir >= 2:
                    sys.stdout.write(chr(27)+chr(91)+ch)
                    sys.stdout.flush()
                    cursor += 1 if dir == 2 else -1
                else:
                    if dir == 0: frm, to = preinputs, nextinputs
                    else: frm, to = nextinputs, preinputs
                    if len(frm) <= 0: continue
                    l = len(curinput)
                    to.append(curinput)
                    curinput = frm.pop()
                    sys.stdout.write('\b' * cursor + ' ' * l + '\b' * l)
                    sys.stdout.write(curinput)
                    sys.stdout.flush()
                    cursor = len(curinput)
        elif ord(ch) == 13:
            if len(nextinputs) > 0: preinputs.append(curinput)
            while len(nextinputs) > 1: preinputs.append(nextinputs.pop())
            preinputs.append(curinput)
            sys.stdout.write('\n'); break
        elif ord(ch) == 127:
            if cursor <= 0: continue
            l = len(curinput)
            curinput = curinput[:cursor-1] + curinput[cursor:]
            sys.stdout.write('\b' * cursor + ' ' * l + '\b' * l)
            sys.stdout.write(curinput)
            cursor -= 1
            rightShiftCursor(cursor - len(curinput))
            sys.stdout.flush()
        else:
            curinput = curinput[:cursor] + ch + curinput[cursor:]
            sys.stdout.write('\b' * cursor + curinput)
            cursor += 1
            rightShiftCursor(cursor - len(curinput))
            sys.stdout.flush()
    return curinput

if __name__ == "__main__":
    while True:
        expr = RealTimeInput("Expression: ")
        if expr.strip() == '': break
        varlist = expr
        for c in set(opchars + digits):
            varlist = varlist.replace(c, ' ')
        vars = {}; vis = []
        for var in list(varlist.split()):
            if var in ['pi', 'e'] + vis: continue
            while True:
                try: vars[var] = eval(input(var + " = ")); break
                except Exception: pass
            vis.append(var)
        print('-' * 20)
        try: print(expr, '=', evaluate(expr, **vars)); print()
        except Exception as error: print("Fail to evaluate: " + str(error))
