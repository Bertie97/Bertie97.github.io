from random import randint

def kmax_sort(array, k=1):
    array.sort()
    return array[-k]

def kmax(array, k=1):
    if len(array) == 1: return array[0]
    boss = array[randint(0, len(array) - 1)] # randomly select a ruler
    smaller = [x for x in array if x < boss]
    equal = [x for x in array if x == boss]
    bigger = [x for x in array if x > boss]
    if len(bigger) >= k: return kmax(bigger, k)
    elif len(bigger) + len(equal) < k: return kmax(smaller, k - len(bigger) - len(equal))
    else: return boss

if __name__ == "__main__":
    array = [randint(1, int(1e7)) for i in range(10)]
    print(array)
    k = int(input("K: "))
    print(kmax(array, k))
