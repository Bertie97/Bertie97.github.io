import string

def wordcount(text):
    for c in set(text) - set(string.ascii_letters + "'-"):
        text = text.replace(c, ' ')
    return len(text.split())

if __name__ == "__main__":
    print(wordcount(open("text.txt").read()))
