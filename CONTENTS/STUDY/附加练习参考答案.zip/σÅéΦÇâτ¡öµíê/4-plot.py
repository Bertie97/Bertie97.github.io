
def plot(func, width=100, height=40, xlim=[0, 1], ylim=[0, 2], xlabel="x", ylabel="y"):
    x = [(u * (xlim[1] - xlim[0]) / width) + xlim[0] for u in range(width)]
    y = [height - (func(u) - ylim[0]) * height / (ylim[1] - ylim[0]) for u in x]
    y = [int(round(u)) for u in y]
    board = [[0 for _ in range(width)] for _ in range(height)]
    for i in range(width):
        if 0 <= y[i] < height:
            board[y[i]][i] = True
    print("^ " + ylabel)
    print('\n'.join(['|' + ''.join(['*' if i else ' ' for i in row]) for row in board]))
    print('+' + '-' * width + "> " + xlabel)

if __name__ == "__main__":
    from math import cos, pi
    plot(cos, xlim=[-pi, pi], ylim=[-1, 1], ylabel="cos(x)")
