
def fpower(x, k):
    k = int(k)
    pow = 1
    while k > 0:
        if k % 2 == 1: pow *= x
        k >>= 1; x **= 2
    return pow

if __name__ == "__main__":
    a = 4.3; b = 123
    print(a**b)
    print(fpower(a, b))
