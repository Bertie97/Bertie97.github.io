
def flatIterable_(iterable_):
    ans = []
    try:
        for x in iterable_:
            ans.extend(flatIterable_(x))
    except TypeError:
        return [iterable_]
    return ans

def flatlist_(list_):
    ans = []
    if type(list_) != list: return [list_]
    for x in list_:
        ans.extend(flatlist_(x))
    return ans

def flatlist(list_):
    items = str(list_).replace('[', '').replace(']', '').split(',')
    return list(eval(','.join([x for x in items if x.strip() != ''])))

if __name__ == "__main__":
    lst = [1,3,[3,[4,5,[6],[[], {1:2}],3],(0,1),2]]
    print(flatlist(lst))
    print(flatlist_(lst))
    print(flatIterable_(lst))
