
from math import e, pi

def str2num(expr):
    try: return int(expr)
    except ValueError: pass
    try: return float(expr)
    except ValueError: raise ValueError("Wrong expression!")

def calculate(expr, depth):
    global digits, operators
    for opr, dir, func in operators:
        if opr.count('.') == 1: raise RuntimeError("Not implemented. ")
        if opr.count('.') == 2: raise RuntimeError("Not implemented. ")
        if opr.count('.') >= 3: raise SyntaxError("Wrong operator - " + opr)


def evaluate(expr, **variables):
    global vars
    vars = variables
    vars.update({'pi': pi, 'e': e})
    expr = expr.replace(' ', '')

    iinsert = []
    for i in range(len(expr) - 1):
        if expr[i] in digits and expr[i+1] not in digits and expr[i+1] not in opchars:
            iinsert.append(i+1)
    expr = list(expr)
    for i in iinsert[::-1]:
        expr.insert(i, '*')
    expr = ''.join(expr)

    depth, count = [], 0
    for c in expr:
        if c == '(': count += 1
        if c == ')': count -= 1
        depth.append(count)

    return calculate(expr, depth)


operators = [('(.)',  0, lambda x: x),
             ('.+.', -1, lambda x, y: x + y),
             ('.-.', -1, lambda x, y: x - y),
             ('.*.', -1, lambda x, y: x * y),
             ('./.', -1, lambda x, y: x / y),
             ('.^.', +1, lambda x, y: x ** y),
             ('.**.',+1, lambda x, y: x ** y),
             ('+.' ,  0, lambda x: x),
             ('-.' ,  0, lambda x: -x),
             ('.'  ,  0, lambda ex: vars.get(ex, None))]

digits = ".01223456789"
opchars = ''.join([x[0] for x in operators])

if __name__ == "__main__":
    while True:
        expr = input("Expression: ")
        if expr.strip() == '': continue
        varlist = expr
        for c in set(opchars + digits):
            varlist = varlist.replace(c, ' ')
        vars = {}; vis = []
        for var in list(varlist.split()):
            if var in ['pi', 'e'] + vis: continue
            while True:
                try: vars[var] = eval(input(var + " = ")); break
                except Exception: pass
            vis.append(var)
        print()
        try: print(expr, '=', evaluate(expr, **vars))
        except Exception as error: print("Fail to evaluate: " + str(error))
