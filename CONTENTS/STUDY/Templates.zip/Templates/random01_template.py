
from random import randint
from tools import periodic
import os
import threading

width = 100; height = 40

@periodic(0.1)
def ontimer():
    os.system('clear')
    # CODE HERE

ontimer()
